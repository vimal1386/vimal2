package com.espire.cabbooking1.ui;
import java.sql.SQLException;
import java.util.Scanner;

import com.espire.cabbooking1.connection.DBConnection;
import com.espire.cabbooking1.daoimpl.AdminDaoImpl;
import com.espire.cabbooking1.daoimpl.PassengerDaoImpl;

public class LoginUI {
	public static void main(String[]args) throws SQLException {
		DBConnection connection = new DBConnection();
		PassengerDaoImpl impl=new PassengerDaoImpl();
		AdminDaoImpl adminImpl=new AdminDaoImpl();
		Scanner scan=new Scanner(System.in);
		int n;
		do {
        System.out.println("Select the Number\n"
        		+ "1. Admin\n"
        		+ "2. User\n");
        n=scan.nextInt();
		switch(n) {
        case 1:
        	System.out.println("Enter id:");
        	int id=scan.nextInt();
        	System.out.println("Enter password");
        	int pass=scan.nextInt();
        	if(id==1 && pass== 1)
        	{
        	char ch;
        	System.out.println("Select the Chararacter\n"
            		+ "a. View all cabs\n"
            		+ "b. View all passengers\n"
            		+ "c. View all bookings\n");
        	ch=scan.next().charAt(0);
        	switch(ch) {
        	case 'a':
        		adminImpl.viewAllCabs();
        		break;
        	case 'b':
        		adminImpl.viewAllPassengers();
        		break;
        	case 'c':
        		adminImpl.viewAllBookings();
        		break;
        	}
        	}
        	else {
        		System.out.println("Wrong credentials");
        	}
             break;
        case 2:
        	char vim;
        	System.out.println("Select the Character\n"
            		+ "a. Book The Ride\n"
            		+ "b. Cancel The Ride\n");
        	vim=scan.next().charAt(0);
        	switch(vim) {
        	case 'a':
        		impl.bookTheRide();
        		break;
        	case 'b':
        		impl.cancelTheBooking();
        		break;
        	}
            break;
        default:
            System.out.println("Not a valid choice");
            break;
		}
		}while(true);
	}
}
