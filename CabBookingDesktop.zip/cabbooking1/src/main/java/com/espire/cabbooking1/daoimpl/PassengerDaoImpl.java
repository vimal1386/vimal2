package com.espire.cabbooking1.daoimpl;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Scanner;
import com.espire.cabbooking1.dao.PassengerDAO;
import com.espire.cabbooking1.serviceimpl.PassengerServiceImpl;

public class PassengerDaoImpl implements PassengerDAO{
	PassengerServiceImpl serImpl=new PassengerServiceImpl();
	Scanner scan=new Scanner(System.in);
	public void bookTheRide() throws SQLException {
		System.out.println("Enter booking id");
        int bId=scan.nextInt();
        scan.nextLine();
//      System.out.println("Enter booking Date and time");
        Timestamp ts=new Timestamp(System.currentTimeMillis());
//        SimpleDateFormat sdf = new SimpleDateFormat("dd-mm-yyyy");
//        String bDate=scan.nextLine();
        System.out.println("Enter booking Status");
        String bStatus=scan.nextLine();
//        boolean bn = "true" != null;
        serImpl.add(bId,ts,bStatus);
        return;
	}

	public void cancelTheBooking() throws SQLException {
		System.out.println("Enter booking id");
        int bId=scan.nextInt();
		serImpl.delete(bId);
		return;
	}
	
}
