package com.espire.cabbooking1.service;

import java.sql.SQLException;
import java.sql.Timestamp;

public interface PassengerService {
	void add(int bId, Timestamp bDate, String bStatus)throws SQLException;
    void delete(int bId)throws SQLException;
}
