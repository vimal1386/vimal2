package com.espire.cabbooking1;

public class Cab {
	private int cabNo;
	private int driverId;
	private String cabModel;
	private String cabColor;
	private String availibility;
	private boolean check;
	
	public Cab(){}
	
	public Cab(int cabNo, int driverId, String cabModel, String cabColor, String availibility, boolean check) {
		this.cabNo = cabNo;
		this.driverId = driverId;
		this.cabModel = cabModel;
		this.cabColor = cabColor;
		this.availibility = availibility;
		this.check = check;
	}
	
	public int getCabNo() {
		return cabNo;
	}
	public void setCabNo(int cabNo) {
		this.cabNo = cabNo;
	}
	public int getDriverId() {
		return driverId;
	}
	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}
	public String getCabModel() {
		return cabModel;
	}
	public void setCabModel(String cabModel) {
		this.cabModel = cabModel;
	}
	public String getCabColor() {
		return cabColor;
	}
	public void setCabColor(String cabColor) {
		this.cabColor = cabColor;
	}
	public String getAvailibility() {
		return availibility;
	}
	public void setAvailibility(String availibility) {
		this.availibility = availibility;
	}
	public boolean isCheck() {
		return check;
	}
	public void setCheck(boolean check) {
		this.check = check;
	}

	@Override
	public String toString() {
		return "Cab [cabNo=" + cabNo + ", driverId=" + driverId + ", cabModel=" + cabModel + ", cabColor=" + cabColor
				+ ", availibility=" + availibility + ", check=" + check + "]";
	}
	
}
